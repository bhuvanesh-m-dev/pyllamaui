const { activate } = require('./activate');
const { deactivate } = require('./deactivate');

module.exports = { activate, deactivate };
