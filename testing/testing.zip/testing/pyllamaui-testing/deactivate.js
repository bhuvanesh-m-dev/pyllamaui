function deactivate() {}

module.exports = { deactivate };
