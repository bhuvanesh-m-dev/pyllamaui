# main.py
# Entry point for PyLlamaUI, initializes the GUI and connects components

import sys
import os

# Add local libs to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(current_dir, "libs"))

import tkinter as tk
from ui_components import ChatApp
from api import OllamaAPI

def main():
    # Initialize the main Tkinter window
    root = tk.Tk()
    
    # Create Ollama API instance
    api = OllamaAPI(base_url="http://localhost:11434")
    
    # Create and start the chat application
    app = ChatApp(root, api)
    
    # Start the Tkinter event loop
    root.mainloop()

if __name__ == "__main__":
    main()
